# REA — Reverse Engineer Anything

**状态：VERIFIED_DOCS；优先级 P1**  
官方：https://rea.tools/  源码：https://github.com/morluto/rea  

## 用途与能力
REA 给 Codex 等编程代理提供 MCP/CLI 逆向调查能力，包括本地二进制、JavaScript/Electron、网站及运行时行为；浏览器侧可观察前端资源、页面交互和网络流量，产出可追溯证据。官方安装指令 `npx rea-agents@latest setup`，需先审阅更改。

## LOONG 初步用途
1. RoTerminal：研究 Rising、Screener、CCU 历史曲线、图表实现与客户端聚合方式。
2. Entropy Advisors：研究 TVL、tokenization 资产分类、数据请求和前端可见计算。
3. 未来行业站：寻找信息图、过滤器、图表交互等简洁实现。

## 首轮实验
独立 Chrome profile 打开公开页面 → 连接 CDP → 检查一项功能与网络请求 → 保存 URL、时间、资源路径及代码摘录 → 手工验证结果 → 写清服务端未知部分。第一轮只研究「Entropy TVL 口径」和「RoTerminal Rising 排序」。

## 限制/风险
无法直接读取第三方远程后台代码；接口可见不等于可长期抓取；CDP 隔离登录资料；保留版权/条款；不在 Cloudflare Worker 安装逆向工具。勿将推断标为已验证。

## 来源
- https://rea.tools/ — How it works / Set up REA
- https://github.com/morluto/rea — README / What you can analyze
