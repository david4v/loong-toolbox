# AIHOT — AI 新闻精选和多源事件系统

**状态：VERIFIED_DOCS；优先级 P1**  
源码：https://github.com/KKKKhazix/AIHOT  许可：MIT（代码），名称和 Logo 不在授权内。

## 已公开的工作流
1. 多源输入：RSS、网页列表、JSON API、X 账号、微信公众号、自定义推送。
2. 去重和预筛，候选**独立两次打分**；过门槛后写标题与摘要。
3. 事件聚簇：最近两周标题/摘要嵌入召回；无 embedding 时可用文本重叠；LLM 判断同一事件、进展或独立事件；写入前复核。
4. 事件热度：48 小时内按**独立来源**计数、单来源仅计一次，每 24 小时贡献减半；防止重复转载刷榜。
5. 日报→周报/月报；提示词在 `industry/prompts/` 便于独立维护。

## LOONG 最重要的借鉴
- 全球新闻：将「文章」与「事件」分离，事件页呈现多来源证据，重复报道不重复展示。
- 公司情报：保留官方公告全量、事件级辅助聚簇，**不允许因聚类而误删监管公告**。
- 质量：双评审仅用于高价值候选，成本受控；记录分数和入选理由。
- 多源：X 与公众号新增观察池时，采用统一输入契约（source_id、published_at、original_url、raw_text、fetch_time）。

## 可借鉴但不要照搬
AIHOT 基于 Node/TypeScript、PostgreSQL、pg-boss、Docker。LOONG 目前 Cloudflare Workers/D1/Python 容器已运行，先提炼算法/测试而非全面迁移技术栈。AIHOT 公共仓库不包含其生产信源名单及运营数据。

## 最小验证
用 30 条同事件多媒体稿、10 条独立稿、10 条官方公告标注真值，评估误合并/漏合并与模型调用成本；不通过则保持实验状态。

## 来源
- https://github.com/KKKKhazix/AIHOT — README / 工作流、聚簇与热点、许可
- https://github.com/KKKKhazix/AIHOT/blob/main/README.en.md — How it works / Clustering and heat
