# World Monitor — 全球实时情报系统

**状态：VERIFIED_DOCS；优先级 P1（研究）；许可风险高**  
源码：https://github.com/koala73/worldmonitor  文档：https://worldmonitor.app/docs

## 可复用思路
实时新闻、地缘政治、航班/船舶、能源/市场/灾害、预测市场等多源同屏；3D/2D 地图与专题面板；跨数据流信号交叉验证；本地模型、三层缓存、来源新鲜度记录；按 world/tech/finance 等变体共用代码。官方还有 CLI、SDK、REST API、MCP（调用可能需要 key）。

## 特别值得拆解的模块
- `ARCHITECTURE.md`：部署拓扑、服务分层、源配置、刷新策略。
- `src/workers/analysis.worker.ts`：新闻 Jaccard 聚簇、跨领域相关性。
- `src/workers/ml.worker.ts`：客户端 embedding、实体识别等；注意模型大小和浏览器负担。
- `src/config/map-layer-definitions.ts`：统一图层清单，按场景开关。
- `src/config/variant.ts`：按用途复用同一 UI 平台。
- `src/utils/`、服务缓存：新鲜度、节流、并发、异常诊断设计。

## LOONG 初步用途
宏观观察的地理事件视图（战争、能源、政策）；股价或主题异动时交叉查看新闻、预测市场与基础设施信号。长期可用于航天发射与卫星活动等专题研究。短期先梳理数据源与算法；无意复制复杂地图产品。

## 许可与安全
官方**AGPL-3.0-only**；研究架构思想通常与复制代码不同，直接将源码模块并入私有服务可能产生 AGPL 义务，实施前逐项审查。外部免费数据源并不自动免费授权商用；MCP 接口是否需要订阅单独核实。不得把该仓库整个代码导入 LOONG。

## 首轮试验
只选「跨数据流关联」与「source freshness」两个子系统，将现有 LOONG 日报 1 天窗口作为对照，比较准确率、延迟、成本。

## 来源
- https://github.com/koala73/worldmonitor — README / Programmatic Access、License
- https://github.com/koala73/worldmonitor/blob/main/ARCHITECTURE.md — System Overview、State Management、Web Workers、Deployment Topology
