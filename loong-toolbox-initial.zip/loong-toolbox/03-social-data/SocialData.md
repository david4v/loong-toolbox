# SocialData — 第三方 X 数据 API 与 MCP

**状态：CANDIDATE；优先级 P1**  
官网：https://socialdata.tools/  价格：https://docs.socialdata.tools/getting-started/pricing/

## 已公开能力
公开 X 帖子、账号、搜索与线程等 REST JSON；官方还提供可直接让 AI 助手调用的只读 MCP。大部分端点公开价 **$0.20 / 1,000 项**；预充值且余额不失效，个别端点费率不同。另有独立的监控/轮询定价机制，不能把「数据按条收费」误认为所有自动监控零固定成本。

## LOONG 初步用途
作为 TwitterAPI.io 的对照与潜在备选：100 账号日增量，筛出一手技术、产品、订单、监管、业内专家观点。保留帖源与上下文，不直接把转发热度当业务事实。AIHOT 可提供去重、聚簇和日报逻辑。

## 成本示例
每天每账号 2/10/30 帖，100 账号 × 30 天，帖费约 $1.20/$6.00/$18.00，**只算内容返回费**。使用监控托管服务可能是完全不同的价格：官方 monitoring 文档列出按小时/每监控计费。

## 验证清单
选相同 10 个账号，连续 7 天与 TwitterAPI.io 对照覆盖率、发布时间、漏帖率、分页成本、余额扣费、API 故障。对 100 账号不要采用默认高频托管监控。

## 来源
- https://socialdata.tools/ — API、MCP、Usage-based pricing
- https://docs.socialdata.tools/getting-started/pricing/ — Per-endpoint Pricing
- https://docs.socialdata.tools/monitoring/pricing/ — Monitors Pricing
