# TwitterAPI.io — 第三方 X 数据 API

**状态：CANDIDATE；优先级 P1**  
官网：https://twitterapi.io/  价格：https://twitterapi.io/pricing

## 适用功能
付费 REST API 抓取公开 X 帖子、账号资料、搜索等，不需自己长期运营浏览器爬虫。官网当前披露 tweets **$0.15 / 1,000**，其他 profile 与功能按端点收费，可能有充值和折扣结构。

## LOONG 使用设想
用户提交约 100 个重点账户 → 每日增量抓取 → 保留 post_id、user_id、发布时间、原文、链接、被引用对象、媒体链接及互动数据 → 用 AIHOT 的事件聚簇算法做主题归因、信噪分层、观点变化追踪 → 进入「X 观察池」。

## 成本示例（仅帖费）
100 账号，每天每账号 2/10/30 帖，30 天分别为 6,000/30,000/90,000 帖，基础帖费约 $0.90/$4.50/$13.50；未计 API 查询附加收费、重复翻页、资料查询、模型总结、税费和失败重试。必须用真实请求验收账单。

## 验证清单
核对账号 timeline 的增量和分页、置顶帖/转推处理、历史补抓、数据延迟、去重、长期服务稳定性、合法使用条件、充值支持地区及支付工具。生产密钥只能放 Cloudflare Secrets。

## 来源
- https://twitterapi.io/pricing — Tweets、Profiles、Volume Pricing
