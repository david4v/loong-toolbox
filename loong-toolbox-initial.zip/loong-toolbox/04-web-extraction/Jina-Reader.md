# Jina Reader / Search — 网页转可读文本

**状态：VERIFIED_DOCS（产品）；未完成 LOONG 实测；P2**  
API 文档：https://docs.jina.ai/  产品：https://jina.ai/reader/  价格：https://jina.ai/api-dashboard/pricing/

## 能力
`r.jina.ai/{url}` 把 HTML / PDF 网页提取为适合 LLM 读取的 Markdown；Reader 可匿名低速调用，API key 提供更高限额且涉及按 token 计费；`s.jina.ai` 提供搜索端点，需要 key。Reader 可使用浏览器渲染模式（以及可配置的抓取引擎），但不能保证每个付费墙或反爬页面可读。

## LOONG 用途
作为**单一可选抓取通道**实验：从搜索结果/官网 URL 到可引用正文；重点测试 Reuters、Bloomberg（若被拒绝必须明确失败）、SCMP、Nikkei 等站，以及长篇英文博客和财报 PDF。只在原路径失败且合规时尝试；按用户既定工程原则，不设计静默兜底链路。

## 验证
固定 20 个 URL：可阅读率、正文保真、发布日期和出处保留、耗时、token 花费、是否有幻觉内容。对不合法访问不尝试绕过。

## 来源
- https://docs.jina.ai/ — Reader API、Search API、Authentication
- https://jina.ai/api-dashboard/pricing/ — Rate Limits、Token Usage
