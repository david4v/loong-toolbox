# Entropy Advisors — Robinhood Chain Analytics 参考产品

**状态：RESEARCH_TARGET**  
网站：https://robinhood.entropyadvisors.com/

## 研究对象
TVL、稳定币、市值、桥接流量、DEX 和 tokenized assets 仪表盘。重要任务是确认指标口径，例如链上 TVL 与稳定币市值如何去重、不同链/协议如何归属、哪些交易被视为净流入。

## 对 LOONG 用途
建立 USDC/USDT/OUSD 与代币化证券的可复核指标清单、分辨一手链上数据与二次加工数字。可以学习设计与定义，不能直接假定接口允许生产抓取。

## 首轮试验
选一条 TVL 指标：记录公开文字定义 → REA 检视客户端网络请求和计算 → 用独立链上或数据平台样本交叉复核 → 标注尚不能验证的后端部分。

## 来源
- https://robinhood.entropyadvisors.com/ — Overview / Protocol TVL / Asset Landscape
