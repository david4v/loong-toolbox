# RoTerminal — Roblox 数据与图表参考产品

**状态：RESEARCH_TARGET；不是已授权数据源**  
网站：https://roterminal.co/?r=all

## 研究对象
Rising、Screener、Trends、游戏 CCU/历史曲线、集中度和热力图。重点问：实时 CCU 多久抽样一次？峰值取最大瞬时值还是窗口平滑值？Rising 以绝对增量、百分比或多因子排序？是否区分机器人、峰值异常及排名变化？

## 对 LOONG 用途
重建经独立核实的指标定义与研究方法；为 Roblox 平台的爆款生命周期、Top10 集中度、Discovery 改革提供高频证据。Roblox 周报目前暂停，**不自动恢复**。

## 研究方法
REA/CDP 仅查看公开页面、浏览器可见网络/JS 计算；样本比对观察排序，不假设后台算法可恢复。尊重服务条款及抓取限制。

## 来源
- https://roterminal.co/?r=all — 产品公开页面（指标口径待 REA 实测）
