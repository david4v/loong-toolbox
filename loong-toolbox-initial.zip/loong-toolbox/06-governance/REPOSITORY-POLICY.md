# 公开与私有、Actions、版权和工程边界

## 建议
**本仓库建议 PUBLIC**：内容是公开开源项目的链接、事实、来源与原创评估，无密钥、内部情报和交易数据。便于分享、查阅和外部贡献；以后需要沉淀个人采购报价或敏感研究时，应放回私有 `loong-os`（或新建另一个私有仓库），本库只放通用工具说明。

## GitHub Actions 的实际政策
GitHub 官方文档：公开仓库使用**标准 GitHub-hosted runners** 不计执行分钟费；私有仓库使用账户额度（GitHub Free 一般 2,000 分钟/月）。但公开仓库不等于「所有资源无限免费」：larger runners 仍收费；Artifacts/Storage、缓存、并发与单任务时限等仍受政策约束。GitHub Actions 还必须满足平台服务条款。

**因此不可通过把含密钥/内部算法的生产仓库改为 public 来规避额度。** 当前 LOONG 生产调度已转 Cloudflare，保持该设计。本工具仓库默认 **零 workflow**，未来可加轻量链接有效性检查，不进行持续大规模抓取。

## 许可证
- AIHOT：MIT，品牌及 Logo 不包含。
- World Monitor：AGPL-3.0-only，复制至网络服务/私有代码需专业审查；优先学习方法而非直接粘贴源码。
- REA 与各供应商许可应在实际引入时重新审查版本。
- 第三方 REST API 的服务使用条款与 GitHub 源码许可证是两件事。

## 不准入库
密钥/Token/Cookie、Cloudflare Access 配置、用户资产及持仓、非公开研究结论、第三方付费数据正文、未经授权复制的完整网站前端。

## 来源
- https://docs.github.com/en/actions/concepts/billing-and-usage — Billing and usage / Usage limits and policy
- https://docs.github.com/en/billing/concepts/product-billing/github-actions — Free use of GitHub Actions / Storage billing
- https://github.com/koala73/worldmonitor — README / License
- https://github.com/KKKKhazix/AIHOT — README / 许可
