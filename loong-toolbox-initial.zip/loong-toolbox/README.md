# LOONG Toolbox — 开发工具与开源方案研究库

> 2026-10-25 初版。独立于生产系统 `david4v/loong-os`。这是**调研索引与可复用设计知识库**，不是部署工程、付费 API 账号仓库或第三方代码镜像。

## 工作原则

Simple · Efficient · Elegant；Fail early · Fix fast。优先复用成熟方案，不自行造轮子；不为候选工具改变生产架构。每条资料分为「官方证实」「初步设想」「待实测」，不能将推测写成已验证结论。

## 分类

| 分类 | 内容 | 当前优先级 |
|---|---|---|
| `01-reverse-engineering/` | REA：研究优秀网站的前端功能和浏览器可见计算逻辑 | P1 |
| `02-intelligence-frameworks/` | AIHOT、World Monitor：采集、精选、聚类、信号交叉验证、情报地图 | P1 |
| `03-social-data/` | TwitterAPI.io、SocialData：100 个 X 账号观察池 | P1（候选） |
| `04-web-extraction/` | Jina Reader、Dajiala：网页正文与微信公众号内容 | P2（候选） |
| `05-reference-products/` | RoTerminal、Entropy：指标和图表产品逆向研究题库 | P1 |
| `06-governance/` | 权利、采购、成本、公开仓库及 GitHub Actions 管控 | 必须 |

## 状态定义
- `VERIFIED_DOCS`：官方文档确认能力，**不表示我们已运行成功**。
- `CANDIDATE`：需求匹配，费用/稳定性/合规仍待验收。
- `RESEARCH_TARGET`：外部参考产品，不预设有公开接口或许可。
- `INTEGRATED`：经 LOONG 真实环境验证并进入生产，需附 PR/日志证据。**本次无此状态。**

## 借鉴的界限
只记录官方文档、算法思想、指标定义、链接与最小测试方案。未经许可不镜像第三方数据与源码，不放登录 Cookies、API keys、爬虫绕过技巧、生产 Cloudflare 配置、个人组合和商业机密。World Monitor 的 AGPL-3.0-only 代码不能未经许可直接并入私有 LOONG 生产代码；可学习架构思想，实际复制需单独合规审查。

## LOONG 接入准则
任何候选先答 5 个问题：增量价值是什么？有无现成免费来源？月成本与支付方式？失败时能否明确报错？是否必须修改现有 Cloudflare 架构？通过才单独立项。此库自身不定时抓取、不启用 Actions。

## 快速开始
先阅读每个文件的「用途 → 已证实 → 预期用法 → 验证任务 → 风险 → 来源」，再建立单独实验。任何生产变更均在 loong-os 走 PR，不从本库自动发布。
